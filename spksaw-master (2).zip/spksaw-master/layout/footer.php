<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2023 &copy; SPK - SAW pemilihan motor metic</p>
        </div>
        <div class="float-end">
            <p>Crafted with <span class="text-danger"><i class="bi bi-heart"></i></span> by <a
                    href="http://github.com/rickyginting">kolompok_kecerdasan_buatan</a></p>
        </div>
    </div>
</footer>
